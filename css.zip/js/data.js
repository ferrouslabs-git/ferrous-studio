// Static component metadata, labels, and pattern presets.
(() => {
  const api = window.VSUB = window.VSUB || {};

  api.COMPONENT_TYPES = {
    navbar:     { group: 'Structure',    label: 'Nav bar',           desc: 'App header with logo, links, avatar' },
    sidebar:    { group: 'Structure',    label: 'Sidebar',           desc: 'Vertical nav rail or section list' },
    tabs:       { group: 'Structure',    label: 'Tabs',              desc: 'Horizontal tab bar for sub-sections' },
    breadcrumb: { group: 'Structure',    label: 'Breadcrumb',        desc: 'Location trail' },
    footer:     { group: 'Structure',    label: 'Footer',            desc: 'Page-level footer bar' },
    hero:       { group: 'Content',      label: 'Hero',              desc: 'Full-width banner or intro section' },
    kpi:        { group: 'Content',      label: 'KPI row',           desc: 'Metric tiles: numbers at a glance' },
    list:       { group: 'Content',      label: 'List / table',      desc: 'Rows of records with actions' },
    chart:      { group: 'Content',      label: 'Chart',             desc: 'Bar / line / pie data visualisation' },
    detail:     { group: 'Content',      label: 'Detail panel',      desc: 'Single-record read view (key → value)' },
    empty:      { group: 'Content',      label: 'Empty state',       desc: 'Zero-data / first-run placeholder' },
    main:       { group: 'Content',      label: 'Main content',      desc: 'Generic rich-text or summary area' },
    form:       { group: 'Interaction',  label: 'Form',              desc: 'Input fields for create / edit' },
    filters:    { group: 'Interaction',  label: 'Filter / search',   desc: 'Search box + filter chips' },
    stepper:    { group: 'Interaction',  label: 'Stepper',           desc: 'Multi-step progress indicator' },
    modal:      { group: 'Interaction',  label: 'Modal / dialog',    desc: 'Overlay dialog box' },
    actions:    { group: 'Interaction',  label: 'Footer actions',    desc: 'Save / cancel button row' },
  };

  api.DEFAULT_LABELS = {
    navbar: 'App', sidebar: 'Sidebar', tabs: 'Tabs', breadcrumb: 'Breadcrumb', footer: 'Footer',
    hero: 'Hero', kpi: 'Metrics', list: 'List', chart: 'Chart', detail: 'Detail',
    empty: 'No data yet', main: 'Main', form: 'Form', filters: 'Search bar',
    stepper: 'Steps', modal: 'Dialog', actions: 'Actions',
  };

  api.PATTERNS = [
    {
      id: 'empty-screen',
      icon: 'EMP',
      name: 'Empty screen',
      desc: 'Blank screen with no components',
      components: [],
    },
    {
      id: 'nav-only',
      icon: 'NAV',
      name: 'Screen with nav only',
      desc: 'Top navigation only',
      components: ['navbar'],
    },
    {
      id: 'nav-left-panel',
      icon: 'N+L',
      name: 'Screen with nav and left panel',
      desc: 'Top nav with left-side panel',
      components: ['navbar', 'sidebar', 'main'],
    },
    {
      id: 'left-panel-only',
      icon: 'LFT',
      name: 'Screen with left panel only',
      desc: 'Left-side panel without top nav',
      components: ['sidebar', 'main'],
    },
    {
      id: 'left-right-panel',
      icon: 'L+R',
      name: 'Screen with left and right panels',
      desc: 'Left sidebar plus right detail panel',
      components: ['sidebar', 'main', 'detail'],
    },
    {
      id: 'nav-left-right-panel',
      icon: 'NLR',
      name: 'Screen with nav, left and right panels',
      desc: 'Top nav with left sidebar and right detail panel',
      components: ['navbar', 'sidebar', 'main', 'detail'],
    },
  ];
})();
